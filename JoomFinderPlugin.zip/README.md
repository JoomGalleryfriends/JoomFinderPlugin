# JoomFinderPlugin
This package extends the index based serach of Joomla! (Smart Search).
